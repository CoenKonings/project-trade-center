from django.apps import AppConfig


class TradeCenterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'trade_center'
